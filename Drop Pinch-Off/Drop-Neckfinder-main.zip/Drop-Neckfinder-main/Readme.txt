To set up the notebook, open an anaconda prompt in the install directory and run the following commands:

conda env create -f environment.yml
conda activate DropPinchoff
jupyter notebook